/*
 * GET users listing.
 */

exports.list = function(req, res) {
	var queryString = 'SELECT * FROM lista_movimenti';
	recupera(queryString, res);
};

exports.insertMovimento = function(req, res){
	var nome = req.body.nome;
	var cognome = req.body.cognome;
	res.json({ status: 'OK'});
};

exports.getMovimento = function(req, res){
	var queryString = 'SELECT * FROM lista_movimenti where id = '+req.params.id;
	recupera(queryString, res);
};

exports.deleteMovimento = function(req, res){
	var user_name=req.body.user;
};

exports.getSaldo = function(req, res){
	var result;
	var connectionObject = require('../common/connection.js');
	var math = require('mathjs');
	var thisConnection = new connectionObject();
	thisConnection.connect();
	
	var querySaldoIniziale = 'SELECT saldo_iniziale FROM saldo_iniziale WHERE id_utente = 1';
	var queryDifferenza = 'SELECT SUM(accrediti) - SUM(addebiti) AS differenza FROM lista_movimenti WHERE id_utente = 1';
	var saldoIniziale;
	var saldoDiff;
	
	
	thisConnection.query(querySaldoIniziale, function(err, rows, fields) {
		if (err) throw err;
		var obj = rows[0];
		saldoIniziale = obj.saldo_iniziale;
		console.log(saldoIniziale);
		//return saldoIniziale;
	});
	
	thisConnection.query(queryDifferenza, function(err, rows, fields) {
		if (err) throw err;
		var obj = rows[0];
		saldoDiff = obj.differenza;
		console.log(saldoDiff);
		//return saldoDiff;
	});
	
	//var somma = add(saldoArray[0], saldoArray[1], 10);
	//var somma  = math.add(5.1554,-54.1248);
	var somma  = math.add(saldoIniziale,saldoDiff);
	
	console.log(somma);
	
	var saldo = {
		"saldo" : somma
	};
	
	//console.log(saldo);
	res.json(saldo);
	
	thisConnection.end();
};

function recupera(queryString, res){
	var result;
	var connectionObject = require('../common/connection.js');
	var thisConnection = new connectionObject();
	thisConnection.connect();
	
	thisConnection.query(queryString, function(err, rows, fields) {
		if (err) throw err;
		var listaMovimenti = [];

		for ( var i in rows) {
			var movimento = {
				"id" : rows[i].id,
				"accrediti" : rows[i].accrediti,
				"addebiti" : rows[i].addebiti,
				"data_contabile" : rows[i].data_contabile,
				"data_valuta" : rows[i].data_valuta,
				"descrizione_operazioni" : rows[i].descrizione_operazioni,
				"codice_causale" : rows[i].codice_causale,
				"id_utente" : rows[i].id_utente
			};

			listaMovimenti.push(movimento);
		}
		console.log(listaMovimenti);
		result = res.json(listaMovimenti);
	});
	
	thisConnection.end();
};
