
/**
 * Module dependencies.
 */

var express = require('express')
  , routes = require('./routes')
  , user = require('./routes/user')
  , listaMovimenti = require('./routes/listaMovimenti')
  , http = require('http')
  ,	cors = require('cors') 
  , bodyParser = require('body-parser')
  , path = require('path');

var app = express();

// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', __dirname + '/views');
app.set('view engine', 'jade');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.bodyParser());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({
	extended : false
}));

app.use(cors());

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

app.get('/', routes.index);
app.get('/users', user.list);


//gestione listaMovimenti
app.get('/listaMovimenti/:id', listaMovimenti.getMovimento);
app.get('/listaMovimenti', listaMovimenti.list);
app.get('/getSaldo', listaMovimenti.getSaldo);

app.post('/listaMovimentiInsert', listaMovimenti.insertMovimento);
app.del('/listaMovimentiDelete', listaMovimenti.deleteMovimento);

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});
