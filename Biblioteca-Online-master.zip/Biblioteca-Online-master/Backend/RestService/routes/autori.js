/*
 * GET users listing.
 */

exports.list = function(req, res) {
	var queryString = 'SELECT * FROM autori';
	recupera(queryString, res);
};

exports.insertAutore = function(req, res){
	var nome = req.body.nome;
	var cognome = req.body.cognome;
	res.json({ status: 'OK'});
};

exports.getAutore = function(req, res){
	var queryString = 'SELECT * FROM autori where id = '+req.params.id;
	recupera(queryString, res);
};

exports.deleteAutore = function(req, res){
	var user_name=req.body.user;
};

function recupera(queryString, res){
	var result;
	var connectionObject = require('../common/connection.js');
	var thisConnection = new connectionObject();
	thisConnection.connect();
	
	thisConnection.query(queryString, function(err, rows, fields) {
		if (err) throw err;
		var listaAutori = [];

		for ( var i in rows) {
			var autore = {
				"id" : rows[i].id,
				"nome" : rows[i].nome,
				"cognome" : rows[i].cognome
			};

			listaAutori.push(autore);
		}
		console.log(listaAutori);
		result = res.json(listaAutori);
	});
	
	thisConnection.end();
};
