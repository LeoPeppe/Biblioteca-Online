exports.insertOrdine = function(req, res) {
	var descrizione = req.body.descrizione;
	var dataInoltro = req.body.dataInoltro;
	var dataConsegna = req.body.dataConsegna;
	var idAzienda = req.body.idAzienda;
	var idLibro = req.body.idLibro;
	res.json({
		status : 'OK'
	});
};

exports.getOrdine = function(req, res) {
	var queryString = 'SELECT * FROM ordini where id = '+req.params.id;
	recupera(queryString, res);
};

exports.getOrdini = function(req, res) {
	var queryString = 'SELECT * FROM ordini';
	recupera(queryString, res);
};

exports.deleteOrdine = function(req, res) {

};

function recupera(queryString, res){
	var result;
	var connectionObject = require('../common/connection.js');
	var thisConnection = new connectionObject();
	thisConnection.connect();
	
	thisConnection.query(queryString, function(err, rows, fields) {
		if (err) throw err;
		var listaOrdini = [];

		for ( var i in rows) {
			var ordine = {
				"id" : rows[i].id,
				"descrizione" : rows[i].descrizione,
				"data_inoltro" : rows[i].data_inoltro,
				"data_consegna" : rows[i].data_consegna,
				"id_azienda" : rows[i].id_azienda,
				"id_libro" : rows[i].id_libro
			};

			listaOrdini.push(ordine);
		}
		console.log(listaOrdini);
		result = res.json(listaOrdini);
	});
	
	thisConnection.end();
};