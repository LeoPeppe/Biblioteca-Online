exports.insertVendita = function(req, res){
	var user_name=req.body.user;
	  var password=req.body.password;
	  res.json({ status: 'OK'});  
};

exports.getVendite = function(req, res){
	var queryString = 'SELECT * FROM vendite';
	recupera(queryString, res);
};

exports.getVendita = function(req, res){
	var queryString = 'SELECT * FROM vendite where id = '+req.params.id;
	recupera(queryString, res);
};

exports.deleteVendita = function(req, res){
	
};

function recupera(queryString, res){
	var connectionObject = require('../common/connection.js');
	var thisConnection = new connectionObject();
	thisConnection.connect();
	var result;
	thisConnection.query(queryString, function(err, rows, fields) {
		if (err) throw err;
		var listaVendite = [];

		for ( var i in rows) {
			var vandita = {
				"id" : rows[i].id,
				"id_persona" : rows[i].id_persona,
				"id_libro" : rows[i].id_libro,
				"data" : rows[i].data,
				"numero_fattura" : rows[i].numero_fattura
			};

			listaVendite.push(vandita);
		}
		console.log(listaVendite);
		result = res.json(listaVendite);
	});
	
	thisConnection.end();
	
};