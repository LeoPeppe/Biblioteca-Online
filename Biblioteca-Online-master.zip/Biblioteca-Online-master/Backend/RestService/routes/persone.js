exports.insertPersona = function(req, res){
	var user_name=req.body.user;
	  var password=req.body.password;
	  res.json({ status: 'OK'});  
};

exports.getPersona = function(req, res){
	var queryString = 'SELECT * FROM persone where id = '+req.params.id;
	recupera(queryString, res);
};

exports.getPersone = function(req, res){
	var queryString = 'SELECT * FROM persone';
	recupera(queryString, res);
};

exports.deletePersona = function(req, res){
	
};

function recupera(queryString, res){
	var result;
	var connectionObject = require('../common/connection.js');
	var thisConnection = new connectionObject();
	thisConnection.connect();
	
	thisConnection.query(queryString, function(err, rows, fields) {
		if (err) throw err;
		var listaPersone = [];

		for ( var i in rows) {
			var persona = {
				"id" : rows[i].id,
				"codice_fiscale" : rows[i].codice_fiscale,
				"nome" : rows[i].data_inoltro,
				"cognome" : rows[i].nome,
				"data_nascita" : rows[i].data_nascita,
				"id_comune_residenza" : rows[i].id_comune_residenza,
				"indirizzo_residenza" : rows[i].indirizzo_residenza,
				"numero_telefono" : rows[i].numero_telefono,
				"professione" : rows[i].professione,
				"sesso" : rows[i].sesso
			};

			listaPersone.push(persona);
		}
		console.log(listaPersone);
		result = res.json(listaPersone);
	});
	
	thisConnection.end();
};