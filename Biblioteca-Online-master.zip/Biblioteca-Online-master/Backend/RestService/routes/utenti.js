exports.insertUtente = function(req, res){
	var user_name=req.body.user;
	  var password=req.body.password;
	  res.json({ status: 'OK'});  
};

exports.getUtenti = function(req, res){
	var queryString = 'SELECT * FROM utenti';
	recupera(queryString, res);
};

exports.getUtente = function(req, res){
	var queryString = 'SELECT * FROM utenti where id = '+req.params.id;
	recupera(queryString, res);
};

exports.deleteUtente = function(req, res){
};

function recupera(queryString, res){
	var connectionObject = require('../common/connection.js');
	var thisConnection = new connectionObject();
	thisConnection.connect();
	var result;
	thisConnection.query(queryString, function(err, rows, fields) {
		if (err) throw err;
		var listaUtenti = [];

		for ( var i in rows) {
			var utente = {
				"id" : rows[i].id,
				"id_persona" : rows[i].id_persona,
				"id_azienda" : rows[i].id_azienda,
				"id_ruolo" : rows[i].id_ruolo,
				"nome_utente" : rows[i].nome_utente,
				"password" : rows[i].password
			};

			listaUtenti.push(utente);
		}
		console.log(listaUtenti);
		result = res.json(listaUtenti);
	});
	
	thisConnection.end();
	
};