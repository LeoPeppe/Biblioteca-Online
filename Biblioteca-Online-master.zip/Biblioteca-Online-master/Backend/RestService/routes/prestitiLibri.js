exports.insertPrestitoLibro = function(req, res){
	var user_name=req.body.user;
	  var password=req.body.password;
	  res.json({ status: 'OK'});  
};

exports.getPrestitiLibri = function(req, res){
	var queryString = 'SELECT * FROM prestiti_libri';
	recupera(queryString, res);
};

exports.getPrestitoLibro = function(req, res){
	var queryString = 'SELECT * FROM prestiti_libri where id = '+req.params.id;
	recupera(queryString, res);
};

exports.deletePrestitoLibro = function(req, res){
};

function recupera(queryString, res){
	var result;
	var connectionObject = require('../common/connection.js');
	var thisConnection = new connectionObject();
	thisConnection.connect();
	
	thisConnection.query(queryString, function(err, rows, fields) {
		if (err) throw err;
		var listaPrestitiLibri = [];

		for ( var i in rows) {
			var prestito = {
				"id" : rows[i].id,
				"id_libro" : rows[i].id_libro,
				"id_persona" : rows[i].id_persona,
				"data_consegna_libro" : rows[i].data_consegna_libro,
				"data_ritorno_libro" : rows[i].data_ritorno_libro,
				"quota_lasciata" : rows[i].quota_lasciata,
				"documento_lasciato" : rows[i].documento_lasciato
				
			};

			listaPrestitiLibri.push(prestito);
		}
		console.log(listaPrestitiLibri);
		result = res.json(listaPrestitiLibri);
	});
	
	thisConnection.end();
};