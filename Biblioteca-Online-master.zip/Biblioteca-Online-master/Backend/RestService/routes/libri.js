exports.insertLibro = function(req, res) {
	var titolo = req.body.titolo;
	var descrizione = req.body.descrizione;
	var prezzo = req.body.prezzo;
	var idCategoria = req.body.idCategoria;
	var idAutore = req.body.idAutore;
	var idCasaEditrice = req.body.idCasaEditrice;

	res.json({
		status : 'OK'
	});
};

exports.getLibri = function(req, res) {
	var queryString = 'SELECT * FROM libri';
	recupera(queryString, res);
};

exports.getLibro = function(req, res) {
	var queryString = 'SELECT * FROM libri where id = '+req.params.id;
	recupera(queryString, res);
};

exports.deleteLibro = function(req, res) {

};

function recupera(queryString, res){
	var result;
	var connectionObject = require('../common/connection.js');
	var thisConnection = new connectionObject();
	thisConnection.connect();
	
	thisConnection.query(queryString, function(err, rows, fields) {
		if (err) throw err;
		var listaLibri = [];

		for ( var i in rows) {
			var libro = {
				"id" : rows[i].id,
				"titolo" : rows[i].titolo,
				"descrizione" : rows[i].descrizione,
				"prezzo" : rows[i].prezzo,
				"id_categoria" : rows[i].id_categoria,
				"id_autore" : rows[i].id_autore,
				"id_casa_editrice" : rows[i].id_casa_editrice
			};

			listaLibri.push(libro);
		}
		console.log(listaLibri);
		result = res.json(listaLibri);
	});
	
	thisConnection.end();
};