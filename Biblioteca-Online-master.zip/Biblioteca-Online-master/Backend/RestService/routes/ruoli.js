exports.insertRuolo = function(req, res){
	var user_name=req.body.user;
	  var password=req.body.password;
	  res.json({ status: 'OK'});  
};

exports.getRuoli = function(req, res){
	var queryString = 'SELECT * FROM ruoli';
	recupera(queryString, res);

};

exports.getRuolo = function(req, res){
	var queryString = 'SELECT * FROM ruoli where id = '+req.params.id;
	recupera(queryString, res);
};

exports.deleteRuolo = function(req, res){
	
};

function recupera(queryString, res){
	var result;
	var connectionObject = require('../common/connection.js');
	var thisConnection = new connectionObject();
	thisConnection.connect();
	
	thisConnection.query(queryString, function(err, rows, fields) {
		if (err) throw err;
		var listaRuoli = [];

		for ( var i in rows) {
			var ruolo = {
				"id" : rows[i].id,
				"descrizione" : rows[i].descrizione,
				"livello" : rows[i].livello
			};

			listaRuoli.push(ruolo);
		}
		console.log(listaRuoli);
		result = res.json(listaRuoli);
	});
	
	thisConnection.end();
};