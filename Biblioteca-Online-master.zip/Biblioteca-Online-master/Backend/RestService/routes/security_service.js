exports.login = function(req, res){
	var user_name=req.body.user;
	  var password=req.body.password;
	  res.json({ status: 'OK'});  
};
exports.logout = function(req, res){
	var user_name=req.body.user;
	  var password=req.body.password;
	  res.json({ status: 'OK'});  
};