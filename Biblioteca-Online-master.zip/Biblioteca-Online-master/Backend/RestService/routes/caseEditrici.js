exports.getAllCaseEditrici = function(req, res){
	var queryString = 'SELECT * FROM case_editrici';
	recupera(queryString, res);
};

exports.insertCasaEditrice = function(req, res){
	var descrizione=req.body.descrizione;
	res.json({ status: 'OK'});  
};

exports.getCasaEditrice = function(req, res){
	var queryString = 'SELECT * FROM case_editrici where id = '+req.params.id;
	recupera(queryString, res);

};
exports.deleteCasaEditrice = function(req, res){
	
};

function recupera(queryString, res){
	var result;
	var connectionObject = require('../common/connection.js');
	var thisConnection = new connectionObject();
	thisConnection.connect();
	
	thisConnection.query(queryString, function(err, rows, fields) {
		if (err) throw err;
		var listaCaseEditrici = [];

		for ( var i in rows) {
			var casaEditrice = {
				"id" : rows[i].id,
				"descrizione" : rows[i].descrizione
			};

			listaCaseEditrici.push(casaEditrice);
		}
		console.log(listaCaseEditrici);
		result = res.json(listaCaseEditrici);
	});
	
	thisConnection.end();
};