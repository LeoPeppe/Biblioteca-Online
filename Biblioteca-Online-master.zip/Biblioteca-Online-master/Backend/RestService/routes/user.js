exports.getUtenti = function(req, res) {
	res.send("respond with a resource");
};
exports.getUtente = function(req, res) {
	res.send("respond with a resource");
};
exports.insertUtente = function(req, res) {
	var user_name=req.body.user;
	  var password=req.body.password;
	  res.json({ status: 'OK'});  
};
exports.deleteUtente = function(req, res) {
	res.send("respond with a resource");
};