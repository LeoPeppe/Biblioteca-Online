exports.getAziendaById = function(req, res){
	var queryString = 'SELECT * FROM aziende where id = '+req.params.id;
	recupera(queryString, res);
};

exports.insertAzienda = function(req, res){
	var ragioneSociale = req.body.ragioneSociale;
	var descrizione = req.body.descrizione;
	var indirizzo = req.body.indirizzo;
	var telefono = req.body.telefono;
	var partitaIva = req.body.partitaIva;
	var idComune = req.body.idComune;
	res.json({ status: 'OK'});
};

exports.listAzienda = function(req, res){
	var queryString = 'SELECT * FROM aziende';
	recupera(queryString, res);
};

exports.deleteAzienda = function(req, res){
	res.json({ user: 'deleteAzienda'});
};

function recupera(queryString, res){
	var result;
	var connectionObject = require('../common/connection.js');
	var thisConnection = new connectionObject();
	thisConnection.connect();
	
	thisConnection.query(queryString, function(err, rows, fields) {
		if (err) throw err;
		var listaAziende = [];

		for ( var i in rows) {
			var azienda = {
				"id" : rows[i].id,
				"ragione_sociale" : rows[i].ragione_sociale,
				"descrizione" : rows[i].descrizione,
				"indirizzo" : rows[i].indirizzo,
				"telefono" : rows[i].telefono,
				"partita_iva" : rows[i].partita_iva,
				"id_comune" : rows[i].id_comune
			};

			listaAziende.push(azienda);
		}
		console.log(listaAziende);
		result = res.json(listaAziende);
	});
	thisConnection.end();
};