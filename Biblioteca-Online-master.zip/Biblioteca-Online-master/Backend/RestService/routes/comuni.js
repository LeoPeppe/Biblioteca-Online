/*
 * GET users listing.
 */

exports.list = function(req, res) {
	var queryString = 'SELECT * FROM comuni_residenza';
	recupera(queryString, res);
};

exports.insertComune = function(req, res){
//	var nome = req.body.nome;
//	var cognome = req.body.cognome;
	res.json({ status: 'OK'});
};

exports.getComuni = function(req, res){
	var queryString = 'SELECT * FROM comuni_residenza where id = '+req.params.id;
	recupera(queryString, res);
};

exports.deleteComune = function(req, res){
	//var user_name=req.body.user;
};

function recupera(queryString, res){
	var result;
	var connectionObject = require('../common/connection.js');
	var thisConnection = new connectionObject();
	thisConnection.connect();
	
	thisConnection.query(queryString, function(err, rows, fields) {
		if (err) throw err;
		var listaComuni = [];

		for ( var i in rows) {
			var comune = {
				"id" : rows[i].id,
				"nome_comune" : rows[i].nome_comune,
				"codice_istat" : rows[i].codice_istat,
				"codice_catastale" : rows[i].codice_catastale
			};

			listaComuni.push(comune);
		}
		console.log(listaComuni);
		result = res.json(listaComuni);
	});
	
	thisConnection.end();
};
