exports.insertTipologiaCategoriaLibro = function(req, res){
	var user_name=req.body.user;
	  var password=req.body.password;
	  res.json({ status: 'OK'});  
};

exports.getTipologieCategorieLibri = function(req, res){
	var queryString = 'SELECT * FROM tipologie_categorie_libri';
	recupera(queryString, res);
};

exports.getTipologiaCategoriaLibro = function(req, res){
	var queryString = 'SELECT * FROM tipologie_categorie_libri where id = '+req.params.id;
	recupera(queryString, res);
};

exports.deleteTipologiaCategoriaLibro = function(req, res){
	
};

function recupera(queryString, res){
	var result;
	var connectionObject = require('../common/connection.js');
	var thisConnection = new connectionObject();
	thisConnection.connect();
	
	thisConnection.query(queryString, function(err, rows, fields) {
		if (err) throw err;
		var listaTipologieCategorie = [];

		for ( var i in rows) {
			var tipologieCategorie = {
				"id" : rows[i].id,
				"descrizione_categoria_libro" : rows[i].descrizione_categoria_libro
			};

			listaTipologieCategorie.push(tipologieCategorie);
		}
		console.log(listaTipologieCategorie);
		result = res.json(listaTipologieCategorie);
	});
	
	thisConnection.end();
	
};