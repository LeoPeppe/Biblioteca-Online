/**
 * Module dependencies.
 */

var express = require('express'), 
	routes = require('./routes'), 
	user = require('./routes/user'), 
	autori = require('./routes/autori'), 
	comuni = require('./routes/comuni'), 
	azienda = require('./routes/azienda'), 
	casaEditrici = require('./routes/caseEditrici'), 
	libri = require('./routes/libri'), 
	ordini = require('./routes/ordini'), 
	persone = require('./routes/persone'), 
	prestitiLibri = require('./routes/prestitiLibri'), 
	ruoli = require('./routes/ruoli'), 
	securityService = require('./routes/security_service'), 
	tipologieCategorieLibri = require('./routes/tipologieCategorieLibri'), 
	utenti = require('./routes/utenti'), 
	vendite = require('./routes/vendite'), 
	http = require('http'), 
	cors = require('cors'), 
	bodyParser = require('body-parser'), 
	path = require('path');

var app = express();
global.mock = true;
console.log(global.mock);
app.use(cors());

// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', __dirname + '/views');
app.set('view engine', 'jade');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.bodyParser());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({
	extended : false
}));

// development only
if ('development' == app.get('env')) {
	app.use(express.errorHandler());
}

app.get('/', routes.index);

//gestione utenti
app.get('/users/:id', user.getUtente);
app.get('/users', user.getUtenti);
app.post('/usersInsert', user.insertUtente);
app.post('/usersDelete', user.deleteUtente);

//gestione comuni
app.get('/comuni/:id', comuni.getComuni);
app.get('/comuni', comuni.list);
app.post('/comuniInsert', comuni.insertComune);
app.del('/comuniDelete', comuni.deleteComune);

//gestione autori
app.get('/autori/:id', autori.getAutore);
app.get('/autori', autori.list);
app.post('/autoriInsert', autori.insertAutore);
app.del('/autoriDelete', autori.list);

//gestione azienda
app.get('/aziende/:id', azienda.getAziendaById);
app.get('/aziende', azienda.listAzienda);
app.post('/aziendeInsert', azienda.insertAzienda);
app.del('/aziendeDelete', azienda.listAzienda);

//gestione case editrici
app.get('/caseEditrici/:id', casaEditrici.getCasaEditrice);
app.get('/caseEditrici', casaEditrici.getAllCaseEditrici);
app.post('/caseEditriciInsert', casaEditrici.insertCasaEditrice);
app.del('/caseEditriciDelete', casaEditrici.deleteCasaEditrice);

//gestione libri
app.get('/libri/:id', libri.getLibro);
app.get('/libri', libri.getLibri);
app.post('/libriInsert', libri.insertLibro);
app.del('/libriDelete', libri.deleteLibro);

//gestione ordini
app.get('/ordini/:id', ordini.getOrdine);
app.get('/ordini', ordini.getOrdini);
app.post('/ordiniInsert', ordini.insertOrdine);
app.del('/ordiniDelete', ordini.deleteOrdine);

//gestione persone
app.get('/persone/:id', persone.getPersona);
app.get('/persone', persone.getPersone);
app.post('/personeInsert', persone.insertPersona);
app.del('/personeDelete', persone.deletePersona);

//gestione prestiti libri
app.get('/prestitiLibro/:id', prestitiLibri.getPrestitoLibro);
app.get('/prestitiLibro', prestitiLibri.getPrestitiLibri);
app.post('/prestitiLibroInsert', prestitiLibri.insertPrestitoLibro);
app.del('/prestitiLibroDelete', prestitiLibri.deletePrestitoLibro);

//gestione ruoli
app.get('/ruoli/:id', ruoli.getRuolo);
app.get('/ruoli', ruoli.getRuoli);
app.post('/ruoloInsert', ruoli.insertRuolo);
app.del('/ruoloDelete', ruoli.deleteRuolo);

//gestione sicurezza
app.post('/login', securityService.login);
app.post('/logout', securityService.logout);

//gestione tipologie categorie libri
app.get('/tipologieCategorieLibri/:id',
		tipologieCategorieLibri.getTipologiaCategoriaLibro);
app.get('/tipologieCategorieLibri',
		tipologieCategorieLibri.getTipologieCategorieLibri);
app.post('/tipologieCategorieLibriInsert',
		tipologieCategorieLibri.insertTipologiaCategoriaLibro);
app.del('/tipologieCategorieLibriDelete',
		tipologieCategorieLibri.deleteTipologiaCategoriaLibro);

//gestione utenti
app.get('/utenti/:id', utenti.getUtente);
app.get('/utenti', utenti.getUtenti);
app.post('/utentiInsert', utenti.insertUtente);
app.del('/utentiDelete', utenti.deleteUtente);

//gestione vendite
app.get('/vendite/:id', vendite.getVendita);
app.get('/vendite', vendite.getVendite);
app.post('/venditeInsert', vendite.insertVendita);
app.del('/venditeDelete', vendite.deleteVendita);

http.createServer(app).listen(app.get('port'), function() {
	console.log('Express server listening on port ' + app.get('port'));
});
