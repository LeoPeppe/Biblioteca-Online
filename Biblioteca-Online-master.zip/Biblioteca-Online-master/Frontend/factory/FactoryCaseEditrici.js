app
		.factory(
				"CasaEditrice",
				function($http, $rootScope) {

					var caseEditrici = [ {
						descrizione : "CasaEditrice 1",
						id : 1
					}, {
						descrizione : "CasaEditrice 2",
						id : 2
					}, {
						descrizione : "CasaEditrice 3",
						id : 3
					} ];

					return {
						all : function() {
							return caseEditrici;
						},
						get : function(id) {
							var result = null;
							angular.forEach(caseEditrici, function(p) {
								if (p.id == id)
									result = p;
							});
							return result;
						},
						insertCasaEditrice : function(casaEditrice) {
							var success = null;

							$http
									.post($rootScope.caseEditriciInsert, {
										descrizione : 'test'
									})
									.success(
											function(data, status, headers,
													config) {
												success = true;
												alert("Casa Editrice inserita con successo!");
											})
									.error(
											function(data, status, headers,
													config) {
												success = false;
												alert("Un errore è avvenuto nell'inserimento della casa editrice!");
											});
							return success;
						}
					};
				});