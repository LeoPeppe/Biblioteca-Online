app.factory("Autore", function($http, $rootScope) {

	var autori = [ {
		nome : "Andrea",
		cognome : "Camilleri",
		id : 1
	}, {
		nome : "Giovann",
		cognome : "Verga",
		id : 2
	}, {
		nome : "Giosuè",
		cognome : "Carducci",
		id : 3
	} ];

	return {
		all : function() {
			return autori;
		},
		get : function(id) {
			var result = null;
			angular.forEach(autori, function(p) {
				if (p.id == id)
					result = p;
			});
			return result;
		},
		insertAutore : function(autore) {
			var success = null;

			$http.post($rootScope.autoriInsert, {
				nome : 'test',
				cognome : 'test_cognome'
			}).success(function(data, status, headers, config) {
				success = true;
				alert("Autore inserito con successo!");
			}).error(function(data, status, headers, config) {
				success = false;
				alert("Un errore è avvenuto nell'inserimento dell'autore!");
			});
			return success;
		},
		getAllAutori : function() {
			var result = null;
			$http.get($rootScope.baseUrlRest + '/getAllAutori').success(
					function(data) {
						alert(data);
						result = data;
					}).error(function(data, status, headers, config) {
				alert("Un errore è avvenuto nella funzione getAllAutori!");
			});
			return result;
		},
		getAutore : function(idAutore) {
			var result = null;
			$http.get($rootScope.baseUrlRest + '/autori/' + idAutore).success(
					function(data, status, headers, config) {
						result = data;
						alert("Autore recuperato con successo!");
					}).error(function(data, status, headers, config) {
				alert("Un errore è avvenuto nel recupero dell'autore!");
			});
			return result;
		},
	};
});