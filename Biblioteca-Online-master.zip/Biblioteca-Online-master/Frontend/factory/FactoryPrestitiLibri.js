app.factory("PrestitoLibro", function($http, $rootScope) {

	var prestitiLibri = [ {
		descrizione : "PrestitoLibro 1",
		id : 1,
		idLibro : "",
		idPersona : "",
		dataConsegnaLibro : "",
		dataRitornoLibro : "",
		quotaLasciata : "",
		documentoLasciato : ""
	}, {
		descrizione : "PrestitoLibro 2",
		id : 2,
		idLibro : "",
		idPersona : "",
		dataConsegnaLibro : "",
		dataRitornoLibro : "",
		quotaLasciata : "",
		documentoLasciato : ""
	}, {
		descrizione : "PrestitoLibro 3",
		id : 3,
		idLibro : "",
		idPersona : "",
		dataConsegnaLibro : "",
		dataRitornoLibro : "",
		quotaLasciata : "",
		documentoLasciato : ""
	} ];

	return {
		all : function() {
			return prestitiLibri;
		},
		get : function(id) {
			var result = null;
			angular.forEach(prestitiLibri, function(p) {
				if (p.id == id)
					result = p;
			});
			return result;
		},
		insertPrestitoLibro : function(prestitoLibro) {
			var success = null;

			$http.post($rootScope.prestitiLibroInsert, {
				titolo : 'test',
				descrizione : 'test',
				prezzo : 'test',
				idCategoria : 'test',
				idAutore : 'test',
				idCasaEditrice : 'test'
			}).success(function(data, status, headers, config) {
				success = true;
				alert("Libro inserito con successo!");
			}).error(function(data, status, headers, config) {
				success = false;
				alert("Un errore è avvenuto nell'inserimento del libro!");
			});
			return success;
		}
	};
});