app.factory("Ruolo", function($http, $rootScope) {

	var ruoli = [ {
		descrizione : "Ruolo 1",
		id : 1,
		livello : "Ruolo 1"
	}, {
		descrizione : "Ruolo 2",
		id : 2,
		livello : "Ruolo 1"
	}, {
		descrizione : "Ruolo 3",
		id : 3,
		livello : "Ruolo 1"
	} ];

	return {
		all : function() {
			return ruoli;
		},
		get : function(id) {
			var result = null;
			angular.forEach(ruoli, function(p) {
				if (p.id == id)
					result = p;
			});
			return result;
		},
		insertRuolo : function(ruolo) {
			var success = null;

			$http.post($rootScope.ruoloInsert, {
				titolo : 'test',
				descrizione : 'test',
				prezzo : 'test',
				idCategoria : 'test',
				idAutore : 'test',
				idCasaEditrice : 'test'
			}).success(function(data, status, headers, config) {
				success = true;
				alert("Libro inserito con successo!");
			}).error(function(data, status, headers, config) {
				success = false;
				alert("Un errore è avvenuto nell'inserimento del libro!");
			});
			return success;
		}
	};
});