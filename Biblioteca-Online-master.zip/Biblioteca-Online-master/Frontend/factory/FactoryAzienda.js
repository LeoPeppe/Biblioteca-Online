app.factory("Azienda", function($http, $rootScope) {

	var aziende = [ {
		descrizione : "Azienda 1",
		id : 1,
		ragioneSociale : "",
		indirizzo : "",
		telefono : "",
		partitaIva : "",
		idComune : "1"
	}, {
		descrizione : "Azienda 2",
		id : 2,
		ragioneSociale : "",
		indirizzo : "",
		telefono : "",
		partitaIva : "",
		idComune : "2"
	}, {
		descrizione : "Azienda 3",
		id : 3,
		ragioneSociale : "",
		indirizzo : "",
		telefono : "",
		partitaIva : "",
		idComune : "3"
	} ];

	return {
		all : function() {
			return aziende;
		},
		get : function(id) {
			var result = null;
			angular.forEach(aziende, function(p) {
				if (p.id == id)
					result = p;
			});
			return result;
		},
		insertAzienda : function(azienda) {
			var success = null;

			$http.post($rootScope.aziendeInsert, {
				ragioneSociale : 'test',
				descrizione : 'test_cognome',
				indirizzo : 'test_cognome',
				telefono : 'test_cognome',
				partitaIva : 'test_cognome',
				idComune : 'test_cognome'
			}).success(function(data, status, headers, config) {
				success = true;
				alert("Azienda inserita con successo!");
			}).error(function(data, status, headers, config) {
				success = false;
				alert("Un errore è avvenuto nell'inserimento dell'azienda!");
			});
			return success;
		},
		getAllAziendeTest : function() {
			$http.get($rootScope.baseUrlRest + '/getAllAzienda').success(
					function(data) {
						alert(data);
					}).error(function(data, status, headers, config) {
				alert("Un errore è avvenuto nella funzione getAllAziende!");
			});
			return null;
		}
	};
});