app.factory("Libro", function($http, $rootScope) {

	var libri = [ {
		descrizione : "Libro 1",
		id : 1,
		titolo : "",
		prezzo : "",
		idCategoria : "",
		idAutore : "",
		idCasaEditrice : ""
	}, {
		descrizione : "Libro 2",
		id : 2,
		titolo : "",
		prezzo : "",
		idCategoria : "",
		idAutore : "",
		idCasaEditrice : ""
	}, {
		descrizione : "Libro 3",
		id : 3,
		titolo : "",
		prezzo : "",
		idCategoria : "",
		idAutore : "",
		idCasaEditrice : ""
	} ];

	return {
		all : function() {
			return libri;
		},
		get : function(id) {
			var result = null;
			angular.forEach(libri, function(p) {
				if (p.id == id)
					result = p;
			});
			return result;
		},
		insertLibro : function(libro) {
			var success = null;

			$http.post($rootScope.libriInsert, {
				titolo : 'test',
				descrizione : 'test',
				prezzo : 'test',
				idCategoria : 'test',
				idAutore : 'test',
				idCasaEditrice : 'test'
			}).success(function(data, status, headers, config) {
				success = true;
				alert("Libro inserito con successo!");
			}).error(function(data, status, headers, config) {
				success = false;
				alert("Un errore è avvenuto nell'inserimento del libro!");
			});
			return success;
		}
	};
});