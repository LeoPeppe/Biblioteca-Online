app.factory("Ordine", function($http, $rootScope) {

	var ordini = [ {
		descrizione : "Ordine 1",
		id : 1,
		dataInoltro : "",
		dataConsegna : "",
		idAzienda : "",
		idLibro : ""
	}, {
		descrizione : "Ordine 2",
		id : 2,
		dataInoltro : "",
		dataConsegna : "",
		idAzienda : "",
		idLibro : ""
	}, {
		descrizione : "Ordine 3",
		id : 3,
		dataInoltro : "",
		dataConsegna : "",
		idAzienda : "",
		idLibro : ""
	} ];

	return {
		all : function() {
			return ordini;
		},
		get : function(id) {
			var result = null;
			angular.forEach(ordini, function(p) {
				if (p.id == id)
					result = p;
			});
			return result;
		},
		insertOrdine : function(ordine) {
			var success = null;

			$http.post($rootScope.ordiniInsert, {
				descrizione : 'test',
				dataInoltro : 'test',
				dataConsegna : 'test',
				idAzienda : 'test',
				idLibro : 'test'
			}).success(function(data, status, headers, config) {
				success = true;
				alert("Ordine inserito con successo!");
			}).error(function(data, status, headers, config) {
				success = false;
				alert("Un errore è avvenuto nell'inserimento dell'ordine!");
			});
			return success;
		}
	};
});