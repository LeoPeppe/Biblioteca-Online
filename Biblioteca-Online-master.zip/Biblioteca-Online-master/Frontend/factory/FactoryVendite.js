app.factory("Vendite", function($http, $rootScope) {

	var vendite = [ {
		idPersona : "",
		idLibro : "",
		data : "",
		numeroFattura : "232",
		id : 1
	}, {
		idPersona : "",
		idLibro : "",
		data : "",
		numeroFattura : "dsd2",
		id : 2
	}, {
		idPersona : "",
		idLibro : "",
		data : "",
		numeroFattura : "wewdc",
		id : 3
	} ];

	return {
		all : function() {
			return vendite;
		},
		get : function(id) {
			var result = null;
			angular.forEach(vendite, function(p) {
				if (p.id == id)
					result = p;
			});
			return result;
		},
		insertVendita : function(vendita) {
			var success = null;

			$http.post($rootScope.venditeInsert, {
				titolo : 'test',
				descrizione : 'test',
				prezzo : 'test',
				idCategoria : 'test',
				idAutore : 'test',
				idCasaEditrice : 'test'
			}).success(function(data, status, headers, config) {
				success = true;
				alert("Libro inserito con successo!");
			}).error(function(data, status, headers, config) {
				success = false;
				alert("Un errore è avvenuto nell'inserimento del libro!");
			});
			return success;
		}
	};
});