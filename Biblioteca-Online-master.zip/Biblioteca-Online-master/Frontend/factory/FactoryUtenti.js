app.factory("Utente", function($http, $rootScope) {

	var utenti = [ {
		descrizione : "Utente 1",
		id : 1,
		idPersona : "",
		idAzienda : "",
		idRuolo : "",
		nomeUtente : "Nome Ut1",
		password : ""
	}, {
		descrizione : "Utente 2",
		id : 2,
		idPersona : "",
		idAzienda : "",
		idRuolo : "",
		nomeUtente : "Nome Ut2",
		password : ""
	}, {
		descrizione : "Utente 3",
		id : 3,
		idPersona : "",
		idAzienda : "",
		idRuolo : "",
		nomeUtente : "Nome Ut3",
		password : ""
	} ];

	return {
		all : function() {
			return utenti;
		},
		get : function(id) {
			var result = null;
			angular.forEach(utenti, function(p) {
				if (p.id == id)
					result = p;
			});
			return result;
		},
		insertUtente : function(utente) {
			var success = null;

			$http.post($rootScope.utentiInsert, {
				titolo : 'test',
				descrizione : 'test',
				prezzo : 'test',
				idCategoria : 'test',
				idAutore : 'test',
				idCasaEditrice : 'test'
			}).success(function(data, status, headers, config) {
				success = true;
				alert("Libro inserito con successo!");
			}).error(function(data, status, headers, config) {
				success = false;
				alert("Un errore è avvenuto nell'inserimento del libro!");
			});
			return success;
		}
	};
});