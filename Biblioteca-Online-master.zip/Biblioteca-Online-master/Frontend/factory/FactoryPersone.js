app.factory("Persona", function($http, $rootScope) {

	var persone = [ {
		id : 1,
		codiceFiscale : "",
		nome : "Test1",
		cognome : "TestA",
		dataNascita : "",
		idComuneResidenza : "",
		indirizzoResidenza : "",
		numeroTelefono : "",
		professione : "",
		sesso : ""
	}, {
		id : 2,
		codiceFiscale : "",
		nome : "Test2",
		cognome : "TestB",
		dataNascita : "",
		idComuneResidenza : "",
		indirizzoResidenza : "",
		numeroTelefono : "",
		professione : "",
		sesso : ""
	}, {
		id : 3,
		codiceFiscale : "",
		nome : "Test3",
		cognome : "TestC",
		dataNascita : "",
		idComuneResidenza : "",
		indirizzoResidenza : "",
		numeroTelefono : "",
		professione : "",
		sesso : ""
	} ];

	return {
		all : function() {
			return persone;
		},
		get : function(id) {
			var result = null;
			angular.forEach(persone, function(p) {
				if (p.id == id)
					result = p;
			});
			return result;
		},
		insertPersona : function(persona) {
			var success = null;

			$http.post($rootScope.personeInsert, {
				titolo : 'test',
				descrizione : 'test',
				prezzo : 'test',
				idCategoria : 'test',
				idAutore : 'test',
				idCasaEditrice : 'test'
			}).success(function(data, status, headers, config) {
				success = true;
				alert("Libro inserito con successo!");
			}).error(function(data, status, headers, config) {
				success = false;
				alert("Un errore è avvenuto nell'inserimento del libro!");
			});
			return success;
		}
	};
});