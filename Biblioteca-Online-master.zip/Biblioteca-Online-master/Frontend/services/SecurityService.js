app.factory("SecurityService", function() {

  return {
    login: function() {
      return null;
    },
    checkPassoword: function(id) {
     return null;
    },
	isAuthenticated: function() {
	  return null;
    }
  };
});