var app = angular
		.module("MyApp", [])
		.config(
				function($routeProvider, $locationProvider) {
					$locationProvider.hashPrefix('!');
					$routeProvider
							.when("/persons", {
								templateUrl : "partials/index.html"
							})
							.when("/persons/:id", {
								templateUrl : "partials/show.html",
								controller : "ShowCtrl"
							})
							.when("/login", {
								templateUrl : "partials/login.html",
								controller : "LoginCtrl"
							})
							.when("/gestioneAutori", {
								templateUrl : "partials/0_gestioneAutori.html",
								controller : "AutoreController"
							})
							.when("/help", {
								templateUrl : "partials/help.html"
							})
							.when("/testPaginazione", {
								templateUrl : "partials/13_listaAutori.html",
								controller : "AutoreController"
							})
							.when(
									"/gestioneAziende",
									{
										templateUrl : "partials/2_gestioneAziende.html",
										controller : "AziendaController"
									})
							.when(
									"/gestioneCaseEditrici",
									{
										templateUrl : "partials/3_gestioneCaseEditrici.html",
										controller : "CasaEditriceController"
									})
							.when(
									"/listaComuni",
									{
										templateUrl : "partials/4_visualizzaComuniResidenza.html",
										controller : "ComuniController"
									})
							.when("/gestioneLibri", {
								templateUrl : "partials/5_gestioneLibri.html",
								controller : "LibriController"
							})
							.when("/gestioneOrdini", {
								templateUrl : "partials/6_gestioneOrdini.html",
								controller : "OrdiniController"
							})
							.when(
									"/gestionePersone",
									{
										templateUrl : "partials/7_gestionePersone.html",
										controller : "PersoneController"
									})
							.when(
									"/gestionePrestitiLibri",
									{
										templateUrl : "partials/8_gestionePrestitiLibri.html",
										controller : "PrestitiLibriController"
									})
							.when("/gestioneRuoli", {
								templateUrl : "partials/9_gestioneRuoli.html",
								controller : "RuoliController"
							})
							.when(
									"/gestioneTipologieCategorieLibri",
									{
										templateUrl : "partials/10_gestioneTipologieCategorieLibri.html",
										controller : "TipologieCategorieLibriController"
									})
							.when(
									"/gestioneUtenti",
									{
										templateUrl : "partials/11_gestioneUtenti.html",
										controller : "UtentiController"
									})
							.when(
									"/gestioneVendite",
									{
										templateUrl : "partials/12_gestioneVendite.html",
										controller : "VenditeController"
									})
							.when(
									"/listaAziendeTest",
									{
										templateUrl : "partials/24_listaAutoriTest.html",
										controller : "AziendaController"
									}).otherwise({
								redirectTo : "/persons"
							});
				}).run(function($rootScope, $location) {

			$rootScope.baseUrlRest = "http://localhost:3000";
			
			$rootScope.usersInsert = $rootScope.baseUrlRest + "/usersInsert";
			$rootScope.comuniInsert = $rootScope.baseUrlRest + "/comuniInsert";
			$rootScope.autoriInsert = $rootScope.baseUrlRest + "/autoriInsert";
			$rootScope.aziendeInsert = $rootScope.baseUrlRest + "/aziendeInsert";
			$rootScope.caseEditriciInsert = $rootScope.baseUrlRest + "/caseEditriciInsert";
			$rootScope.libriInsert = $rootScope.baseUrlRest + "/libriInsert";
			$rootScope.ordiniInsert = $rootScope.baseUrlRest + "/ordiniInsert";
			$rootScope.personeInsert = $rootScope.baseUrlRest + "/personeInsert";
			$rootScope.prestitiLibroInsert = $rootScope.baseUrlRest + "/prestitiLibroInsert";
			$rootScope.ruoloInsert = $rootScope.baseUrlRest + "/ruoloInsert";
			$rootScope.tipologieCategorieLibriInsert = $rootScope.baseUrlRest + "/tipologieCategorieLibriInsert";
			$rootScope.utentiInsert = $rootScope.baseUrlRest + "/utentiInsert";
			$rootScope.venditeInsert = $rootScope.baseUrlRest + "/venditeInsert";

			$rootScope.$on("$routeChangeStart", function(event, next, current) {
				if ($rootScope.loggedInUser == null) {
					// no logged user, redirect to /login
					if (next.templateUrl === "partials/login.html") {
					} else {
						$location.path("/login");
					}
				}
			});
		});

app.factory("Person", function() {

	var persons = [ {
		name : "Peter",
		age : 25,
		id : 1
	}, {
		name : "Stefan",
		age : 35,
		id : 2
	}, {
		name : "Agnes",
		age : 22,
		id : 3
	} ];

	return {
		all : function() {
			return persons;
		},
		get : function(id) {
			var result = null;
			angular.forEach(persons, function(p) {
				if (p.id == id)
					result = p;
			});
			return result;
		}
	};
});

app.factory("Comune", function() {

	var comuni = [ {
		descrizione : "Roma",
		id : 1
	}, {
		descrizione : "Bari",
		id : 2
	}, {
		descrizione : "Milano",
		id : 3
	} ];

	return {
		all : function() {
			return comuni;
		},
		get : function(id) {
			var result = null;
			angular.forEach(comuni, function(p) {
				if (p.id == id)
					result = p;
			});
			return result;
		}
	};
});

app.controller("IndexCtrl", function($scope, Person) {
	$scope.persons = Person.all();
});

app.controller("ShowCtrl", function($scope, $routeParams, Person) {
	$scope.person = Person.get($routeParams.id);
});

app.controller("MainCtrl", function($scope, $location) {
	$scope.menuClass = function(page) {
		var current = $location.path().substring(1);
		return page === current ? "active" : "";
	};
});

app.controller("LoginCtrl", function($scope, $location, $rootScope) {
	$scope.model = {};

	$scope.login = function() {
		$rootScope.loggedInUser = $scope.username;
		$location.path("/persons");
	};
});