app.controller("PrestitiLibriController", function($scope, $http,Libro,Persona,PrestitoLibro) {

$scope.libri = Libro.all();

$scope.persone = Persona.all();

$scope.prestitoLibro = {};

$scope.prestitiLibri = PrestitoLibro.all();

 $scope.addPrestitoLibro = function() {
	PrestitoLibro.insertPrestitoLibro($scope.prestitoLibro);
 };
 
  $scope.getPrestitoLibro = function(id) {
  var prestitoLibro = PrestitoLibro.get(id);
  $scope.prestitoLibro = prestitoLibro;
	return prestitoLibro;
 };
});