app.controller("LibriController", function($scope, $http,TipologiaCategoriaLibro,Autore,CasaEditrice,Libro) {

$scope.libro = {};

$scope.categorie = TipologiaCategoriaLibro.all();

$scope.autori = Autore.all();

$scope.caseEditrici = CasaEditrice.all();

$scope.libri = Libro.all();

 $scope.addLibro = function() {
	Libro.insertLibro($scope.libro);
 };
 
 $scope.getLibro = function(id) {
	var libro = Libro.get(id);
	$scope.libro = libro;
	return libro;
 };
});