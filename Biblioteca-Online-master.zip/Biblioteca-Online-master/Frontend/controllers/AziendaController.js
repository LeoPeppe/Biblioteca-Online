app.controller("AziendaController", function($scope, $http,Comune,Azienda) {

$scope.comuni = Comune.all();

$scope.azienda = {};

$scope.aziende = Azienda.all();

$scope.aziendaSelezionata = null;

 $scope.addAzienda = function() {
 alert($scope.azienda.idComune);
	Azienda.insertAzienda($scope.azienda);
 };
 
 $scope.getAzienda = function(id) {
 var azienda = Azienda.get(id);
 $scope.azienda = azienda;
 $scope.aziendaSelezionata = Azienda.get(1);
	return azienda;
 };
 
  $scope.getAziendeTest = function() {
	Azienda.getAllAziendeTest();
	return null;
 };
});