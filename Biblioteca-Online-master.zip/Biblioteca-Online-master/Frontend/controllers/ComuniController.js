app.controller("ComuniController", function($scope, $http,Comune) {

$scope.comuni = Comune.all();

});