app.controller("UtentiController", function($scope, $http,Persona,Azienda,Ruolo,Utente) {

$scope.utente = {};

$scope.aziende = Azienda.all();

$scope.ruoli = Ruolo.all();

$scope.persone = Persona.all();

$scope.utenti = Utente.all();

 $scope.addUtente = function() {
	Utente.insertUtente($scope.utente);
 };
 
 $scope.getUtente = function(id) {
	var utente = Utente.get(id);
	$scope.utente = utente;
	return utente;
 };
});