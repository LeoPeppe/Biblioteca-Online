app.controller("PersoneController", function($scope,Comune,Persona) {

$scope.persona = {};

$scope.comuniResidenza = Comune.all();

$scope.persone = Persona.all();

 $scope.addPersona = function() {
	Persona.insertPersona($scope.persona);
 };
 
 $scope.getPersona = function(id) {
 var persona = Persona.get(id);
 $scope.persona = persona; 
	return persona;
 };
});