app.controller("VenditeController", function($scope, $http,Libro,Persona,Vendite) {

$scope.vendita = {};

$scope.libri = Libro.all();

$scope.persone = Persona.all();

$scope.vendite = Vendite.all();

 $scope.addVendita = function() {
	Vendite.insertVendita($scope.vendita);
 };
 
  $scope.getVendita = function(id) {
	var vendita = Vendite.get(id);
	$scope.vendita = vendita;
	return vendita;
 };
});