app.controller("OrdiniController", function($scope,Azienda,Libro,Ordine) {

$scope.ordine = {};

$scope.libri = Libro.all();

$scope.aziende = Azienda.all();

$scope.ordini = Ordine.all();

 $scope.addOrdine = function() {
	Ordine.insertOrdine($scope.ordine);
 };
 
 $scope.getOrdine = function(id) {
 var ordine = Ordine.get(id);
 $scope.ordine = ordine;
	return ordine;
 };
});