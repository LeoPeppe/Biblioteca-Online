app.controller("TipologieCategorieLibriController", function($scope, TipologiaCategoriaLibro) {

$scope.tipologiaCategoriaLibro = {};

$scope.tipologieCategorieLibri = TipologiaCategoriaLibro.all();


 $scope.addTipologiaCategoriaLibro = function() {
	TipologiaCategoriaLibro.insertTipologiaCategoriaLibro($scope.tipologiaCategoriaLibro);
 };
 
 $scope.getTipologiaCategoriaLibro = function(id) {
 var tipologiaCategoriaLibro = TipologiaCategoriaLibro.get(id);
 $scope.tipologiaCategoriaLibro = tipologiaCategoriaLibro;
	return tipologiaCategoriaLibro;
 };
});