app.controller("RuoliController", function($scope, Ruolo) {

$scope.ruolo = {};

$scope.ruoli = Ruolo.all();

 $scope.addRuolo = function() {
	Ruolo.insertRuolo($scope.ruolo);
 };
 
   $scope.getRuolo = function(id) {
   var ruolo = Ruolo.get(id);
   $scope.ruolo = ruolo;
	return ruolo;
 };
});