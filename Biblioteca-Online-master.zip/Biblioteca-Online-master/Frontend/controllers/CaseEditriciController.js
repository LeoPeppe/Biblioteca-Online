app.controller("CasaEditriceController", function($scope,CasaEditrice) {

$scope.casaEditrice = {};

$scope.caseEditrici = CasaEditrice.all();

 $scope.addCasaEditrice = function() {
	CasaEditrice.insertCasaEditrice($scope.casaEditrice);
 };
 
 $scope.getCasaEditrice = function(id) {
 var casaEditrice = CasaEditrice.get(id);
 $scope.casaEditrice = casaEditrice;
	return casaEditrice;
 };
});