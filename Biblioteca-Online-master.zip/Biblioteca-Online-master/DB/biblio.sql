/*
SQLyog Ultimate v8.55 
MySQL - 5.6.22-log : Database - bibiliotecadb
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`bibiliotecadb` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `bibiliotecadb`;

/*Table structure for table `autori` */

DROP TABLE IF EXISTS `autori`;

CREATE TABLE `autori` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) DEFAULT NULL,
  `cognome` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `autori` */

insert  into `autori`(`id`,`nome`,`cognome`) values (1,'Pino','Pini'),(2,'Rino','Rini');

/*Table structure for table `aziende` */

DROP TABLE IF EXISTS `aziende`;

CREATE TABLE `aziende` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ragione_sociale` varchar(50) DEFAULT NULL,
  `descrizione` varchar(200) DEFAULT NULL,
  `indirizzo` varchar(50) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `partita_iva` varchar(50) DEFAULT NULL,
  `id_comune` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_aziende_comuni` (`id_comune`),
  CONSTRAINT `FK_aziende_comuni` FOREIGN KEY (`id_comune`) REFERENCES `comuni_residenza` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `aziende` */

insert  into `aziende`(`id`,`ragione_sociale`,`descrizione`,`indirizzo`,`telefono`,`partita_iva`,`id_comune`) values (1,'GermeCom','Azienda di rincoglioniti','Via Milano 9','12313545','454657945643567',1);

/*Table structure for table `case_editrici` */

DROP TABLE IF EXISTS `case_editrici`;

CREATE TABLE `case_editrici` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `descrizione` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `case_editrici` */

insert  into `case_editrici`(`id`,`descrizione`) values (1,'Mondadori');

/*Table structure for table `comuni_residenza` */

DROP TABLE IF EXISTS `comuni_residenza`;

CREATE TABLE `comuni_residenza` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nome_comune` varchar(50) DEFAULT NULL,
  `codice_istat` int(10) DEFAULT NULL,
  `codice_catastale` varchar(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

/*Data for the table `comuni_residenza` */

insert  into `comuni_residenza`(`id`,`nome_comune`,`codice_istat`,`codice_catastale`) values (1,'Bari',72006,'A662'),(2,'Altamura',72004,'A225'),(3,'Molfetta',72029,'F284'),(4,'Bitonto',72011,'A893'),(5,'Monopoli',70043,'F376'),(6,'Corato',72020,'C983'),(7,'Gravina in Puglia',72023,'E155'),(8,'Modugno',72027,'F262'),(9,'Gioia del Colle',70023,'E038'),(10,'Triggiano',72046,'L425'),(11,'Putignano',72036,'H096'),(12,'Terlizzi',72043,'L109'),(13,'Santeramo in Colle',72041,'I330'),(14,'Mola di Bari',72028,'F280'),(15,'Noic? ttaro',72032,'F923'),(16,'Ruvo di Puglia',72038,'H645'),(17,'Conversano',72019,'C975'),(18,'Palo del Colle',72033,'G291'),(19,'Acquaviva delle Fonti',72001,'A048'),(20,'Giovinazzo',72022,'E047'),(21,'Noci',72031,'F915'),(22,'Castellana Grotte',72017,'C134'),(23,'Casamassima',72015,'B923'),(24,'Valenzano',72048,'L571'),(25,'Rutigliano',72037,'H643'),(26,'Polignano a Mare',72035,'G787'),(27,'Adelfia',72002,'A055'),(28,'Capurso',72014,'B716'),(29,'Locorotondo',72025,'E645'),(30,'Cassano delle Murge',72016,'B998'),(31,'Grumo Appula',72024,'E223'),(32,'Turi',72047,'L472'),(33,'Bitetto',72010,'A892'),(34,'Alberobello',72003,'A149'),(35,'Bitritto',72012,'A894'),(36,'Sannicandro di Bari',72040,'I053'),(37,'Toritto',72044,'L220'),(38,'Sammichele di Bari',72039,'H749'),(39,'Cellamare',72018,'C436'),(40,'Binetto',72008,'A874'),(41,'Poggiorsini',72034,'G769');

/*Table structure for table `libri` */

DROP TABLE IF EXISTS `libri`;

CREATE TABLE `libri` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `titolo` varchar(50) DEFAULT NULL,
  `descrizione` varchar(100) DEFAULT NULL,
  `prezzo` double DEFAULT NULL,
  `id_categoria` bigint(20) DEFAULT NULL,
  `id_autore` bigint(20) DEFAULT NULL,
  `id_casa_editrice` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_libri_casa_editrice` (`id_casa_editrice`),
  KEY `FK_libri_autori` (`id_autore`),
  KEY `FK_libri_categorie` (`id_categoria`),
  CONSTRAINT `FK_libri_autori` FOREIGN KEY (`id_autore`) REFERENCES `autori` (`id`),
  CONSTRAINT `FK_libri_casa_editrice` FOREIGN KEY (`id_casa_editrice`) REFERENCES `case_editrici` (`id`),
  CONSTRAINT `FK_libri_categorie` FOREIGN KEY (`id_categoria`) REFERENCES `tipologie_categorie_libri` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `libri` */

insert  into `libri`(`id`,`titolo`,`descrizione`,`prezzo`,`id_categoria`,`id_autore`,`id_casa_editrice`) values (1,'La signora per pene','Libro pornazzo',52,8,1,1);

/*Table structure for table `ordini` */

DROP TABLE IF EXISTS `ordini`;

CREATE TABLE `ordini` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `descrizione` varchar(50) DEFAULT NULL,
  `data_inoltro` date DEFAULT NULL,
  `data_consegna` date DEFAULT NULL,
  `id_azienda` bigint(20) DEFAULT NULL,
  `id_libro` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_ordini_aziende` (`id_azienda`),
  KEY `FK_ordini_libri` (`id_libro`),
  CONSTRAINT `FK_ordini_aziende` FOREIGN KEY (`id_azienda`) REFERENCES `aziende` (`id`),
  CONSTRAINT `FK_ordini_libri` FOREIGN KEY (`id_libro`) REFERENCES `libri` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `ordini` */

/*Table structure for table `persone` */

DROP TABLE IF EXISTS `persone`;

CREATE TABLE `persone` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `codice_fiscale` varchar(20) DEFAULT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `cognome` varchar(50) DEFAULT NULL,
  `data_nascita` date DEFAULT NULL,
  `id_comune_residenza` bigint(20) DEFAULT NULL,
  `indirizzo_residenza` varchar(50) DEFAULT NULL,
  `numero_telefono` varchar(20) DEFAULT NULL,
  `professione` varchar(50) DEFAULT NULL,
  `sesso` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_persone` (`id_comune_residenza`),
  CONSTRAINT `FK_persone` FOREIGN KEY (`id_comune_residenza`) REFERENCES `comuni_residenza` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `persone` */

insert  into `persone`(`id`,`codice_fiscale`,`nome`,`cognome`,`data_nascita`,`id_comune_residenza`,`indirizzo_residenza`,`numero_telefono`,`professione`,`sesso`) values (1,'GNIGNZ81A30G654T','Gino','Ginozzi','0000-00-00',2,'Via delle vie, 6','54454545','Cazzeggiatore','M');

/*Table structure for table `prestiti_libri` */

DROP TABLE IF EXISTS `prestiti_libri`;

CREATE TABLE `prestiti_libri` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_libro` bigint(20) DEFAULT NULL,
  `id_persona` bigint(20) DEFAULT NULL,
  `data_consegna_libro` date DEFAULT NULL,
  `data_ritorno_libro` date DEFAULT NULL,
  `quota_lasciata` double DEFAULT NULL,
  `documento_lasciato` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_prestiti_libri_persone` (`id_persona`),
  KEY `FK_prestiti_libri_libri` (`id_libro`),
  CONSTRAINT `FK_prestiti_libri_libri` FOREIGN KEY (`id_libro`) REFERENCES `libri` (`id`),
  CONSTRAINT `FK_prestiti_libri_persone` FOREIGN KEY (`id_persona`) REFERENCES `persone` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `prestiti_libri` */

/*Table structure for table `ruoli` */

DROP TABLE IF EXISTS `ruoli`;

CREATE TABLE `ruoli` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `descrizione` varchar(20) DEFAULT NULL,
  `livello` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `ruoli` */

insert  into `ruoli`(`id`,`descrizione`,`livello`) values (1,'Amministratore',1),(2,'UtenteAmministrativo',2),(3,'UtenteEsterno',3);

/*Table structure for table `tipologie_categorie_libri` */

DROP TABLE IF EXISTS `tipologie_categorie_libri`;

CREATE TABLE `tipologie_categorie_libri` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `descrizione_categoria_libro` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

/*Data for the table `tipologie_categorie_libri` */

insert  into `tipologie_categorie_libri`(`id`,`descrizione_categoria_libro`) values (1,'Attualit? '),(2,'Antropologia'),(3,'Arte e Architettura'),(4,'Avventura'),(5,'Biografico'),(6,'Biologia'),(7,'Economia'),(8,'Erotici'),(9,'Fantascienza'),(10,'Fantasy'),(11,'Filosofia'),(12,'Fumetti'),(13,'Fotografia'),(14,'Giallo'),(15,'Horror'),(16,'Letteratura e critica letteraria'),(17,'Manualistica'),(18,'Mass Media'),(19,'Musica Cinema o Teatro'),(20,'Narrativa'),(21,'Psicologia'),(22,'Religione'),(23,'Satira'),(24,'Scienze'),(25,'Sport'),(26,'Sociologia'),(27,'Sport'),(28,'Sociologia'),(29,'Storico'),(30,'Turismo e Geografia');

/*Table structure for table `utenti` */

DROP TABLE IF EXISTS `utenti`;

CREATE TABLE `utenti` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_persona` bigint(20) DEFAULT NULL,
  `id_azienda` bigint(20) DEFAULT NULL,
  `id_ruolo` bigint(20) DEFAULT NULL,
  `nome_utente` varchar(20) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_utenti_ruoli` (`id_ruolo`),
  KEY `FK_utenti_persone` (`id_persona`),
  KEY `FK_utenti_aziende` (`id_azienda`),
  CONSTRAINT `FK_utenti_aziende` FOREIGN KEY (`id_azienda`) REFERENCES `aziende` (`id`),
  CONSTRAINT `FK_utenti_persone` FOREIGN KEY (`id_persona`) REFERENCES `persone` (`id`),
  CONSTRAINT `FK_utenti_ruoli` FOREIGN KEY (`id_ruolo`) REFERENCES `ruoli` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `utenti` */

/*Table structure for table `vendite` */

DROP TABLE IF EXISTS `vendite`;

CREATE TABLE `vendite` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_persona` bigint(20) DEFAULT NULL,
  `id_libro` bigint(20) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `numero_fattura` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_vendite_persone` (`id_persona`),
  KEY `FK_vendite_libri` (`id_libro`),
  CONSTRAINT `FK_vendite_libri` FOREIGN KEY (`id_libro`) REFERENCES `libri` (`id`),
  CONSTRAINT `FK_vendite_persone` FOREIGN KEY (`id_persona`) REFERENCES `persone` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `vendite` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
